import os

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.security import check_password_hash, generate_password_hash
import datetime
from helpers import login_required


# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)
# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///users.db")
@app.route("/",methods=["GET","POST"])
def index ():
    if request.method == "GET":
        return render_template ("index.html")

@app.route("/l",methods=["GET","POST"])
@login_required
def l():

    if request.method == "POST":
        id = session["user_id"]
        name_db = db.execute("SELECT name FROM users WHERE id = ? ", id)
        name=name_db[0]["name"]
    else:
        id = session["user_id"]
        name_db = db.execute("SELECT name FROM users WHERE id = ? ", id)
        name=name_db[0]["name"]
        return render_template("index1.html",name=name)
        
@app.route("/register",methods=["GET","POST"])
def register():
    if request.method == "GET":
       return render_template("register.html")
        # Query database for username
    else:
        username=request.form.get("username")
        password=request.form.get("password")
        confirmation=request.form.get("confirmation")

        rows = db.execute("SELECT * FROM users WHERE name = ?;", username)

        if not username:
            return render_template("apology.html",message="Missing Username")
        if not password:
            return render_template("apology.html",message="Missing password")
        if not confirmation :
            return render_template("apology.html",message="Missing Confirm Password")

        # Ensure username not in database
        if len(rows) != 0:
            return render_template("apology.html", message=f"The username '{username}' already exists. Please choose another name.")

        # Ensure first password and second password are matched
        if password != confirmation:
            return render_template("apology.html",message="Your confirm password don't match with your password")


        # Insert username into database
        id = db.execute("INSERT INTO users (name, hash) VALUES (?, ?);",
                        username, generate_password_hash(password))

        # Remember which user has logged in
        session["user_id"] = id

        flash("Registered!","info")

        return redirect("/l")

@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""


    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        username=request.form.get("username")
        password=request.form.get("password")
        # Ensure username was submitted
        if not username:
            return render_template("apology.html",message="Missing Username")
        if not password:
            return render_template("apology.html",message="Missing password")

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE name = ?", request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return render_template("apology.html",message="invalid username and/or password")

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]


        # Redirect user to home page
        return redirect("/l")
        flash("Logged in succeful","info")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")
@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")

@app.route("/contact", methods=["GET", "POST"])
@login_required
def contact():

    if request.method == "GET":
        return render_template("contact.php")
    else:
        name =request.form.get("name")
        email=request.form.get("email")
        message =request.form.get("message")

        if not name:
            return render_template("apologycontact.html",message="Missing your name")
        if not email :
            return render_template("apologycontact.html",message="Missing your email")
        if not message:
            return render_template("apologycontact.html",message="Missing message")
        flash("message was send")
        return redirect ("/l")
        
@app.route("/must_register")
def must_register ():
    if request.method == "GET":
        return render_template("must_register.html")
        
@app.route("/about" , methods=["GET","POST"])        
def about():
    if request.method == "GET":
        return render_template("about.html")
        
@app.route("/price" , methods=["GET","POST"])        
def price():
    if request.method == "GET":
        return render_template("price.html")  

@app.route("/features")        
def features():
    if request.method == "GET":
        return render_template("features.html")

@app.route("/bmr", methods=["GET", "POST"])
def bmr ():
    if request.method == "GET":
        return render_template("bmr.html")
        
@app.route("/do_exercise_home_men")
def do_exercise_home_men():
    if request.method == "GET":
        return render_template ("do_exercise_home_men.html")
        
@app.route("/do_exercise_gym_men")
def do_exercise_gym_men():
    if request.method == "GET":
        return render_template ("do_exercise_gym_men.html")    
        
@app.route("/do_exercise_home_women")
def do_exercise_home_women():
    if request.method == "GET":
        return render_template ("do_exercise_home_women.html")

@app.route("/do_exercise_gym_women")
def do_exercise_gym_women():
    if request.method == "GET":
        return render_template ("do_exercise_gym_women.html")  
        
